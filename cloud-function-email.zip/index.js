/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
var api_key = '2eb0f7e3dfb30374894ef1609778483a-913a5827-4978249e';
var domain = 'act.gpea-mailer.org';
var mailgun = require('mailgun-js')({
    apiKey: api_key,
    domain: domain
});

var defualtRecipient = "chien.hung.liao@greenpeace.org"
var TaipeiRecipient = "shsueh@greenpeace.org"
var TaichungRecipient = "johnny.chou@greenpeace.org"
var KaohsiungRecipient = "sianni.chang@greenpeace.org"

exports.sendMail = (req, res) => {

    const {
        location,
        subject,
        message
    } = req.body;

    let to = [defualtRecipient];

    if (!location || !subject || !message) {
        return res.status(400).send("Missing required params.")
    }


    switch (location){
        case "臺北":
            to.push(TaipeiRecipient);
            break;
        case "臺中":
            to.push(TaichungRecipient);
            break;
        case "高雄":
            to.push(KaohsiungRecipient);
            break;
        default:
            return res.status(400).send("Invalid location")
    }    


    var data = {
        from: 'GreenpeaceRecruiting<gp-recruiting@greenpeace.org>',
        to: to.join(","),
        subject: subject,
        text: message,
        "h:Reply-To": defualtRecipient
    };

    mailgun.messages().send(data, (error, body) => {
        console.log(error);
        if (error) {
            res.status(400).send(error);
        }
        res.send(body);
    });


};